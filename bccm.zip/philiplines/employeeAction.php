<?php
	include 'includes/session.php';
	
	if(isset($_POST['updateProfile'])){
		$full_name = $_POST['full_name'];
		$job_id = $_POST['job_id'];
		$address = $_POST['address'];
		$dob = $_POST['dob'];
		$work_telephone = $_POST['work_telephone'];
		$mobile = $_POST['mobile'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];
		$schedule_id = $_POST['schedule_id'];
		$marital_status = $_POST['marital_status'];
		$location = $_POST['location'];
		$project_alloted = $_POST['project_alloted'];
		$emp_id = $_POST['emp_id'];
		
		
		
		
		$nationality = 'Tongan';
		
		
		$sql = "UPDATE employee_tnqab SET full_name = '$full_name', job_id = '$job_id', gender = '$gender', gender = '$gender', dob = '$dob', marital_status = '$marital_status',address = '$address',work_telephone = '$work_telephone',mobile = '$mobile',email = '$email',location = '$location', division = '$project_alloted', schedule_id = '$schedule_id' WHERE emp_id = '$emp_id'";
		
		
		//$sql = "INSERT INTO employee_tnqab (emp_id, user_id, job_id, full_name, gender, dob, nationality, marital_status, address, work_telephone, mobile, email, location, project_alloted, filename, schedule_id) VALUES ('$emp_id', '$user_id', '$job_id', '$full_name', '$gender', '$dob', '$nationality', '$marital_status', '$address', '$work_telephone','$mobile','$email', '$location', '$project_alloted', '$filename', '$schedule_id')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Employee Details Updated Successfully'.$sql;
		}
		else{
			$_SESSION['error'] = $conn->error.'--->'.$sql;
		}

	}

	if(isset($_POST['add'])){
		$full_name = $_POST['full_name'];
		$job_id = $_POST['job_id'];
		$address = $_POST['address'];
		$dob = $_POST['dob'];
		$work_telephone = $_POST['work_telephone'];
		$mobile = $_POST['mobile'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];
		$schedule_id = $_POST['schedule_id'];
		$marital_status = $_POST['marital_status'];
		$location = $_POST['location'];
		$project_alloted = $_POST['project_alloted'];
		
		
		
		// uploading
		$filename = $_FILES['filename']['name'];
		if(!empty($filename)){
			move_uploaded_file($_FILES['filename']['tmp_name'], 'images/'.$filename);	
		}
		//creating employeeid
		$letters = '';
		$numbers = '';
		foreach (range('A', 'Z') as $char) {
		    $letters .= $char;
		}
		for($i = 0; $i < 10; $i++){
			$numbers .= $i;
		}
		$emp_id = 'TNQ'.rand(0000,9999);
		$user_id = rand(0000,9999);
		$nationality = 'Tongan';
		
		$sql = "INSERT INTO employee_tnqab (emp_id, user_id, job_id, full_name, gender, dob, nationality, marital_status, address, work_telephone, mobile, email, location, project_alloted, filename, schedule_id) VALUES ('$emp_id', '$user_id', '$job_id', '$full_name', '$gender', '$dob', '$nationality', '$marital_status', '$address', '$work_telephone','$mobile','$email', '$location', '$project_alloted', '$filename', '$schedule_id')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Employee added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error.'--->'.$sql;
		}

	}
	else{
		//$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: employee.php');
?>