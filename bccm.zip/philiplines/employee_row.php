<?php 
	include 'includes/session.php';

	if(isset($_POST['id'])){
		$id = $_POST['id'];
		$sql = "SELECT *, employee_tnqab.emp_id AS empid FROM employee_tnqab LEFT JOIN projects ON projects.id=employee_tnqab.id LEFT JOIN schedules ON schedules.id=employee_tnqab.schedule_id WHERE employee_tnqab.id = $id";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		echo json_encode($row);
	}
?>