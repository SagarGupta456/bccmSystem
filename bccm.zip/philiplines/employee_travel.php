<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee Travel <i class="fa fa-external-link-square" aria-hidden="true"></i>

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">        Employee Travel </li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:14px;">
            <div class="box-header with-border">
              <a href="#addnew" data-toggle="modal" class="btn btn-primary btn-sm btn-flat" style="margin-left:45%;"><i class="fa fa-plane"></i> New Travel</a>
            </div>
            <div class="box-body">
              <table align="center" id="example"  class="table table-bordered">
                <thead bgcolor="#666699" style="color:#FFFFFF">
                  <th>Employee</th>
                  <th>Travel Information</th>
				   <th>Travel Dates</th>
                  <th>Action</th>
                </thead>
                <tbody>
                  <?php
                    $sql = "SELECT * FROM employee_tnqab_travel";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
					$empID = $row['employee_id'];
					$sql4363 = "SELECT * FROM employee_tnqab WHERE id = '$empID'";
						$query4363 = $conn->query($sql4363);
					$row3546 = $query4363->fetch_assoc();
                     ?>
                        <tr>
                          <td><i class="fa fa-plane" aria-hidden="true" style="font-size:28px;"></i>&nbsp;&nbsp;&nbsp;<?php echo $row3546['full_name']; ?>  <b>(<?php echo $row3546['emp_id']; ?>)</b></td>
                          <td><?php echo $row['travel_information'] ?></td>
						   <td><?php echo str_replace(",", "&nbsp;/&nbsp;", $row['date_of_travel']); ?><br><br>
						   <?php if($row['disable_login'] == 'on') { ?>
						   <i class="fa fa-calendar-times-o" aria-hidden="true" style="font-size:22px; color:#663333;"></i>&nbsp;<b style="color:#333366">LoggedIn not allowed on these Dates.</b>
						   <?php }else { ?>
						     <i class="fa fa-calendar-times-o" aria-hidden="true" style="font-size:22px; color:#663333;"></i>&nbsp;<b style="color:#333366">LoggedIn  allowed on these Dates.</b>
						   <?php } ?>
						   <br></td>
						 
                          <td>
                            <button class='btn btn-danger btn-sm delete btn-flat' data-id='<?php echo $row['travel_id']; ?>'><i class='fa fa-trash'></i> Delete</button>
                          </td>
                        </tr>
                      <?php 
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/employee_travel_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'position_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#posid').val(response.id);
      $('#edit_divisions').val(response.divisions);
      $('#edit_projects').val(response.projects);
	  $('#edit_description').val(response.description);
      $('#del_posid').val(response.id);
      $('#del_position').html(response.projects);
    }
  });
}
</script>
</body>
</html>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'csv', 'excel'
        ]
    } );
} );
    </script>

