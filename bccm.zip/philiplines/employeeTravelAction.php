<?php
	include 'includes/session.php';
	
	$entry_done_by = $_SESSION['Name_Of_Admin'];
	if(isset($_POST['add'])){
	//print_r($_POST);
	//exit;
		
		$travel_information = $_POST['description'];
		$officer_alloted = $_POST['officer_alloted'];
		$date_of_travel = $_POST['dateOfTravel'];
	    //$sparsparts =  implode("+",$officer_alloted);	
		//$employee_id = implode("+",$_POST['officer_alloted']);
		$disable_login = $_POST['disabledLoggedin'];
		$comments = $_POST['comments'];
		//$projectID = $_POST['projectID'];
	  print_r($officer_alloted);
	 
		foreach($officer_alloted as $employee_id) {
    $sql = "INSERT INTO employee_tnqab_travel (employee_id, travel_information, date_of_travel, disable_login,  entry_done_by) VALUES ('$employee_id','$travel_information','$date_of_travel','$disable_login','$entry_done_by')";
		$status = $conn->query($sql);
		}
		
		if($status){
			$_SESSION['success'] = 'Travel Information added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
	else{
		//$_SESSION['error'] = 'Fill up add form first';
	}

		if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$divisions = $_POST['edit_division_name'];
		


		$sql = "UPDATE divisions SET division_name = '$divisions', entry_done_by = '$entry_done_by' WHERE division_id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Division updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		//$_SESSION['error'] = 'Fill up edit form first';
	}
	
	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$sql = "DELETE FROM projects WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Project deleted successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		//$_SESSION['error'] = 'Select item to delete first';
	}




	header('location: employee_travel.php');

?>