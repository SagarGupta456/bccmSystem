<?php
	include 'includes/session.php';

	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$date_now = $_POST['attendence_Date'];
		$remarks = $_POST['remarks'];
		$logOutnow = date('H:i:s');
				$sql = "SELECT *, attendance.id AS uid FROM attendance LEFT JOIN employee_tnqab ON employee_tnqab.id=attendance.employee_id WHERE attendance.employee_id = '$id' AND date = '$date_now'";
				//echo $sql;
				//exit;
				$query = $conn->query($sql);
				if($query->num_rows < 1){
					$output['error'] = true;
					$output['message'] = 'Cannot Timeout. No time in.';
				}
				else{
					$row = $query->fetch_assoc();
					if($row['time_out'] != '00:00:00'){
						$output['error'] = true;
						$output['message'] = 'You have timed out for today';
					}
					else{
						
						$sql = "UPDATE attendance SET time_out = '$logOutnow', remarks = '$remarks' WHERE id = '".$row['uid']."'";
						//echo $sql;
						//exit;
						if($conn->query($sql)){
							$output['message'] = 'For'.$row['full_name'];
						$_SESSION['success'] = 'Attendance Sign Out successfully'.$output['message'];
						
							$sql = "SELECT * FROM attendance WHERE id = '".$row['uid']."'";
							$query = $conn->query($sql);
							$urow = $query->fetch_assoc();

							$time_in = $urow['time_in'];
							$time_out = $urow['time_out'];

							$sql = "SELECT * FROM employee_tnqab LEFT JOIN schedules ON schedules.id=employee_tnqab.schedule_id WHERE employee_tnqab.id = '$id'";
							$query = $conn->query($sql);
							$srow = $query->fetch_assoc();

							if($srow['time_in'] > $urow['time_in']){
								$time_in = $srow['time_in'];
							}

							if($srow['time_out'] < $urow['time_in']){
								$time_out = $srow['time_out'];
							}

							$time_in = new DateTime($time_in);
							$time_out = new DateTime($time_out);
							$interval = $time_in->diff($time_out);
							$hrs = $interval->format('%h');
							$mins = $interval->format('%i');
							$mins = $mins/60;
							$int = $hrs + $mins;
							if($int > 4){
								$int = $int - 1;
							}

							$sql = "UPDATE attendance SET num_hr = '$int' WHERE id = '".$row['uid']."'";
							$conn->query($sql);
						}
						else{
							$output['error'] = true;
							$output['message'] = $conn->error;
						}
					}
					
				}
			
	
	
	//echo $_SESSION['success'];
	//exit;

	header('location: attendance.php');
	}
	
?>