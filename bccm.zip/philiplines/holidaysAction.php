<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$holiday_name = $_POST['holiday_name'];
		$holiday_date = $_POST['holiday_date'];
		$holiday_remarks = $_POST['holiday_remarks'];
		

		$sql = "INSERT INTO holidays (holiday_name, holiday_date, holiday_remarks) VALUES ('$holiday_name', '$holiday_date', '$holiday_remarks')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Holday added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
	else{
		//$_SESSION['error'] = 'Fill up add form first';
	}


	if(isset($_POST['edit'])){
		$holidayid = $_POST['holidayid'];
		$holiday_name = $_POST['edit_holiday_name'];
		$holiday_date = $_POST['edit_holiday_date'];
		$holiday_remarks = $_POST['edit_holiday_remarks'];

		$sql = "UPDATE holidays SET holiday_name = '$holiday_name', holiday_date = '$holiday_date', holiday_remarks = '$holiday_remarks' WHERE holiday_id = $holidayid";
		if($conn->query($sql)){
			$_SESSION['success'] = 'holiday updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error.'-->'.$sql;
		}
	}
	else{
		//$_SESSION['error'] = 'Fill up edit form first';
	}
	
	
	if(isset($_POST['delete'])){
		$id = $_POST['del_holidayid'];
		$sql = "DELETE FROM holidays WHERE holiday_id = $id";
		if($conn->query($sql)){
			$_SESSION['success'] = 'holiday deleted successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		//$_SESSION['error'] = 'Select item to delete first';
	}


	header('location: set_holidays.php');

?>