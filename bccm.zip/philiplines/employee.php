<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee List

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">        Employee Travel </li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:14px;">
            <div class="box-header with-border">
              <a href="#addnew" data-toggle="modal" class="btn btn-danger btn-sm btn-flat" style="margin-left:45%;"><i class="fa fa-user"></i>&nbsp; New User</a>
            </div>
            <div class="box-body">
              <table align="center" id="example"  class="table table-bordered">
                <thead bgcolor="#666699" style="color:#FFFFFF">
                  <th>User ID</th>
                  
                  <th>Name - Surname</th>
				  <th>Email</th>
                  <th>password</th>
				 
                  <th>Action</th>
                </thead>
                <tbody>
                  <?php
                     $sql = "SELECT *, employee_tnqab.emp_id AS empid FROM employee_tnqab LEFT JOIN projects ON projects.employee_id=employee_tnqab.id LEFT JOIN schedules ON schedules.id=employee_tnqab.schedule_id";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
					
                     ?>
                        <tr>
                          <td><b><?php echo $row['empid']; ?></b></td>
                                                    <td><?php echo $row['full_name']; ?></td>
						   <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['password']; ?></td>
						   
                          <td>
                            <a href="employee_edit22.php?id=<?php echo $row['empid']; ?>" class="btn btn-success btn-sm  btn-flat"><i class="fa fa-edit"></i> Edit</a>
                            <button class="btn btn-danger btn-sm delete btn-flat" data-id="<?php echo $row['id']; ?>"><i class="fa fa-trash"></i> Delete</button>
                          </td>
                        </tr>
                      <?php 
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/employee_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'position_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#posid').val(response.id);
      $('#edit_divisions').val(response.divisions);
      $('#edit_projects').val(response.projects);
	  $('#edit_description').val(response.description);
      $('#del_posid').val(response.id);
      $('#del_position').html(response.projects);
    }
  });
}
</script>
</body>
</html>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'csv', 'excel'
        ]
    } );
} );
    </script>

