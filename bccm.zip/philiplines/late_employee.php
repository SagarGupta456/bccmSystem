<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Late Attendance Summary
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Late Attendance Summary</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!--<div class="modal-body">
			<h3 align="center"> <u>Late Attendance Report</u></h3>
            	<form class="form-horizontal" method="POST" action="attendance_edit.php">
            		<input type="hidden" id="attid" name="id">
					<div class="col-sm-6">
                    <label for="datepicker_edit" class="col-sm-3 control-label">Staff Wise</label>

                    <div class="col-sm-5"> 
                      <select class="form-control" name="project_alloted" id="project_alloted" required>
              <option value="" selected>- All Staff -</option>
              <?php
                          $sql = "SELECT * FROM employee_tnqab";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['id']."'>".$prow['full_name']."</option>
                            ";
                          }
                        ?>
            </select>
                    </div>
                </div>
				<div class="col-sm-6">
                    <label for="datepicker_edit" class="col-sm-3 control-label">Division Wise</label>

                    <div class="col-sm-5"> 
                      <select class="form-control" name="project_alloted" id="project_alloted" required>
              <option value="" selected>- All Division -</option>
              <?php
                          $sql = "SELECT * FROM positions WHERE department <> ''";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['job_id']."'>".$prow['department']."</option>
                            ";
                          }
                        ?>
            </select>
                    </div>
                </div>
				<div class="col-sm-12">&nbsp;</div>
                <div class="col-sm-6">
                    <label for="datepicker_edit" class="col-sm-3 control-label">From Date</label>

                    <div class="col-sm-5"> 
                      <div class="date">
                        <input type="text" class="form-control" id="datepicker_edit" name="edit_date">
                      </div>
                    </div>
                </div>
				<div class="col-sm-6">
                    <label for="datepicker_edit" class="col-sm-3 control-label">To Date</label>

                    <div class="col-sm-5"> 
                      <div class="date">
                        <input type="text" class="form-control" id="datepicker_edit222" name="edit_date">
                      </div>
                    </div>
                </div>
				<div class="col-sm-12">&nbsp;</div>
				<div class="col-sm-5">&nbsp;</div>
				<div class="col-sm-2">
                  

                    <div class="col-sm-5"> 
                      <div class="date">
                   <button type="submit" class="btn btn-danger btn-flat" name="add"><i class="fa fa-save"></i> View Report</button>
                      </div>
                    </div>
                </div>
                
                
          	</div>-->
			 <div class="box-body">&nbsp;</div>
			 
            <div class="box-body">
			<h3 align="center"> <u>Late Attendance Summary</u></h3>
              <table id="example"  class="table table-bordered" style="font-family:Geneva, Arial, Helvetica, sans-serif;">
                <thead bgcolor="#666699" style="color:#FFFFFF">
                  <th class="hidden"></th>
                  <th>Date</th>
                  <th>Employee ID</th>
                  <th>Name</th>
				  <th>Email ID</th>
                  <th>Time In</th>
				   <th>Duration Spent</th>
				    <th>Remark</th>
                </thead>
                <tbody>
                  <?php
				  
                    $sql = "SELECT *, employee_tnqab.emp_id AS empid, attendance.id AS attid FROM attendance LEFT JOIN employee_tnqab ON employee_tnqab.id=attendance.employee_id WHERE time_out <> '' ORDER BY attendance.date DESC, attendance.time_in DESC";
					//echo $sql;
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
					$time1 = new DateTime($row['time_in']);
					$time2 = new DateTime($row['time_out']);
					$interval = $time1->diff($time2);
					//echo $interval->format('%s second(s)');
					$duration_spent = $interval->format('%h hours(s)').'-'.$interval->format('%m minute(s)').'-'.$interval->format('%s second(s)');
					  if($row['time_out'] == '00:00:00')
					  {
					   $statusNotcompleted = '<br><span class="label label-info	 pull-right">Not Logged Out</span>';
					   $duration_spent = '<span class="label label-warning"><b>Not Logged Out from System</b></span>';
					  }else{
					  $statusNotcompleted = '';
					  }
					  if($row['time_in'] > '08:31:00')
					  {
                      $status = ($row['time_in'] > '08:31:00')?'<br><span class="label label-warning pull-right">late</span>':'<br><span class="label label-danger pull-right">ontime</span>';
                      echo "
                        <tr>
                          <td class='hidden'></td>
                          <td>".date('M d, Y', strtotime($row['date']))."</td>
                          <td>".$row['empid']."</td>
						   <td>".$row['email']."</td>
                          <td>".$row['full_name']."</td>
                          <td>".date('h:i A', strtotime($row['time_in'])).$status."</td>
						  <td>".$duration_spent."</td>
                        						   <td>".$row['remarks']."</td>

                        </tr>
                      ";
                    }
					}
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/attendance_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'attendance_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
	//alert(response.full_name);
      $('#datepicker_edit').val(response.date);
      $('#attendance_date').html(response.full_name);
	  $('#del_attendenceDate').val(response.date);
	  
      $('#edit_time_in').val(response.time_in);
      $('#edit_time_out').val(response.time_out);
      $('#attid').val(response.attid);
      $('#employee_name').html(response.firstname+' '+response.lastname);
      $('#del_attid').val(response.id);
      $('#del_employee_name').html(response.full_name+' ('+response.emp_id+')');
    }
  });
}
</script>
</body>
</html>

 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'pdf', 'csv', 'excel'
        ]
    } );
} );
    </script>
