<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php';
	function getTimeDiff($dtime,$atime)
    {
        $nextDay = $dtime>$atime?1:0;
        $dep = explode(':',$dtime);
        $arr = explode(':',$atime);
        $diff = abs(mktime($dep[0],$dep[1],0,date('n'),date('j'),date('y'))-mktime($arr[0],$arr[1],0,date('n'),date('j')+$nextDay,date('y')));
        $hours = floor($diff/(60*60));
        $mins = floor(($diff-($hours*60*60))/(60));
        $secs = floor(($diff-(($hours*60*60)+($mins*60))));
        if(strlen($hours)<2){$hours="0".$hours;}
        if(strlen($mins)<2){$mins="0".$mins;}
        if(strlen($secs)<2){$secs="0".$secs;}
        return $hours.' Hours '.$mins.' Minutes ';
    }

 ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Attendance
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Attendance</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <a href="#addnew" data-toggle="modal" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"></i> Add Attendence</a>
            </div>
            <div class="box-body">
              <table id="example"  class="table table-bordered" style="font-family:Geneva, Arial, Helvetica, sans-serif;">
                <thead bgcolor="#666699" style="color:#FFFFFF">
                  <th class="hidden"></th>
                  <th>Date</th>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Time In</th>
                  <th>Time Out</th>
				   <th>Duration Spent</th>
                  <th>Action</th>
                </thead>
                <tbody>
                  <?php
				  
                    $sql = "SELECT *, employee_tnqab.emp_id AS empid, attendance.id AS attid FROM attendance LEFT JOIN employee_tnqab ON employee_tnqab.id=attendance.employee_id ORDER BY attendance.date DESC, attendance.id DESC";
					//echo $sql;
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
					//$time1 = new DateTime($row['time_in']);
					//$time2 = new DateTime($row['time_out']);
					//$interval = $time1->diff($time2);
					//echo $interval->format('%s second(s)');
					//$duration_spent = $interval->format('%h hours(s)').'-'.$interval->format('%m minute(s)').'-'.$interval->format('%s second(s)');
					  if($row['time_out'] == '00:00:00')
					  {
					   $statusNotcompleted = '<br><span class="label label-info	 pull-right">Not Logged Out</span>';
					   $duration_spent = '<span class="label label-warning"><b>Not Logged Out from System</b></span>';
					   $timeSentt = date('H:i:s');
					  }else{
					  $statusNotcompleted = '';
					  $timeSentt = $row['time_out'];
					  }
					  $timoutrr = date('h:i A', strtotime($row['time_out']));
					  if($timoutrr == '12:00 AM')
					  {
					  	$timoutrr = '---';
						
					  
					  }else{
					  $timoutrr = $timoutrr;
					  }
					  $timeinteraval = getTimeDiff($row['time_in'], $timeSentt);
                     // $status = ($row['status'])?'<br><span class="label label-warning pull-right">ontime</span>':'<br><span class="label label-danger pull-right">late</span>';
                      echo "
                        <tr>
                          <td class='hidden'></td>
                          <td>".date('M d, Y', strtotime($row['date']))."</td>
                          <td>".$row['empid']."</td>
                          <td>".$row['full_name']."</td>
                          <td>".date('h:i A', strtotime($row['time_in']))."</td>
                          <td>".$timoutrr."</td>
						  <td>".$timeinteraval."</td>
                          <td>
                           <button class='btn btn-success btn-sm btn-flat edit' data-id='".$row['attid']."'><i class='fa fa-edit'></i> Edit</button>
                            <button class='btn btn-info btn-sm btn-flat delete' data-id='".$row['attid']."'><i class='fa fa-sign-out'></i> Sign Out</button>
                          </td>
                        </tr>
                      ";
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/attendance_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'attendance_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
	//alert(response.full_name);
      $('#datepicker_edit').val(response.date);
      $('#attendance_date').html(response.full_name);
	  $('#del_attendenceDate').val(response.date);
	  
      $('#edit_time_in').val(response.time_in);
      $('#edit_time_out').val(response.time_out);
      $('#attid').val(response.attid);
      $('#employee_name').html(response.full_name);
	 
      $('#del_attid').val(response.id);
      $('#del_employee_name').html(response.full_name+' ('+response.emp_id+')');
    }
  });
}
</script>
</body>
</html>

 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'csv', 'excel'
        ]
    } );
} );
    </script>
