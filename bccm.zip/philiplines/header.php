<div class="topbar">
    <div class="topbar-left">
      <div class="logo">
        <h1><a href="#">TNQAB</a></h1>
      </div>
      <button class="button-menu-mobile open-left"> <i class="fa fa-bars"></i> </button>
    </div>
    <!-- Button mobile view to collapse sidebar menu -->
    <div class="navbar navbar-default" role="navigation">
      <div class="container">
        <div class="navbar-collapse2">
          <ul class="nav navbar-nav hidden-xs">
            <li class="language_bar dropdown hidden-xs"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">English (US)</a> </li>
          </ul>
          <ul class="nav navbar-nav navbar-right top-navbar">
            <li class="dropdown iconify hide-phone"><a href="#" onClick="javascript:toggle_fullscreen()"><i class="icon-resize-full-2"></i></a></li>
            <li class="dropdown topbar-profile"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="rounded-image topbar-profile-image"><img src="../admin/images/<?php echo $employeeIDRows['filename']; ?>"></span> <?php echo $employeeIDRows['full_name']; ?>  <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu">
                <li><a href="#">My Profile</a></li>
                <li class="divider"></li>
                <li><a href="#"><i class="icon-help-2"></i> Help</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </div>
  </div>