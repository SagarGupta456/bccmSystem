<?php
	include 'includes/session.php';
	
	$entry_done_by = $_SESSION['Name_Of_Admin'];
	if(isset($_POST['add'])){
		$divisions = $_POST['division_name'];
	

		$sql = "INSERT INTO divisions (division_name, entry_done_by) VALUES ('$divisions', '$entry_done_by')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Division added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
	else{
		//$_SESSION['error'] = 'Fill up add form first';
	}

		if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$divisions = $_POST['edit_division_name'];
		


		$sql = "UPDATE divisions SET division_name = '$divisions', entry_done_by = '$entry_done_by' WHERE division_id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Division updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		//$_SESSION['error'] = 'Fill up edit form first';
	}
	
	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$sql = "DELETE FROM divisions WHERE division_id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Division deleted successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		//$_SESSION['error'] = 'Select item to delete first';
	}




	header('location: position.php');

?>