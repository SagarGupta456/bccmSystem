<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; 


		$sql = "SELECT *, employee_tnqab.emp_id AS empid FROM employee_tnqab LEFT JOIN projects ON projects.id=employee_tnqab.id LEFT JOIN schedules ON schedules.id=employee_tnqab.schedule_id WHERE employee_tnqab.emp_id = '".$_GET['id']."'";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

//print_r($row);
//exit;

?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee List

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">        Employee Travel </li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:14px;">
            <div class="box-header with-border">
              <a href="employee.php"  class="btn btn-danger btn-sm btn-flat" style="margin-left:45%;"><i class="fa fa-user"></i>&nbsp; Back To Employee</a>
            </div>
            <div class="modal-body">
      <form class="form-horizontal" method="POST" action="employeeAction.php" enctype="multipart/form-data">
	  <input type="hidden" name="emp_id" id="emp_id" value="<?php echo $_GET['id']; ?>">
        <div class="form-group">
          <label for="firstname" class="col-sm-3 control-label">Employee Name</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="full_name" name="full_name" required placeholder="Employee Full Name" value="<?php echo $row['full_name']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="firstname" class="col-sm-3 control-label">Employee Email</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="email" name="email" required placeholder="Employee Email" value="<?php echo $row['email']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="address" class="col-sm-3 control-label">Address</label>
          <div class="col-sm-6">
            <textarea class="form-control" name="address" id="address" rows="2" cols="50"><?php echo $row['address']; ?></textarea>
          </div>
        </div>
        <div class="form-group">
          <label for="datepicker_add" class="col-sm-3 control-label">Birth Date</label>
          <div class="col-sm-6">
            <div class="date">
              <input type="text" class="form-control" id="datepicker_add" name="dob" placeholder="Date Of Birth" value="<?php echo $row['dob']; ?>">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="contact" class="col-sm-3 control-label">Contact Info</label>
          <div class="col-sm-3">
            <input type="text" class="form-control" id="work_telephone" name="work_telephone" placeholder="Work Telephone" value="<?php echo $row['work_telephone']; ?>">
          </div>
          <div class="col-sm-3">
            <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Phone" value="<?php echo $row['mobile']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="contact" class="col-sm-3 control-label">Nationality</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="Nationality" name="Nationality" value="Tongan" readonly="true">
          </div>
        </div>
        <div class="form-group">
          <label for="contact" class="col-sm-3 control-label">Location</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="location" name="location"  value="<?php echo $row['location']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="gender" class="col-sm-3 control-label">Gender</label>
          <div class="col-sm-6">
            <select class="form-control" name="gender" id="gender" required>
              <option value="" selected>- Select -</option>
              <option value="Male" <?php if($row['gender'] == 'Male') { echo "selected"; }?> >Male</option>
              <option value="Female" <?php if($row['gender'] == 'Female') { echo "selected"; }?>>Female</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="gender" class="col-sm-3 control-label">Marital Status</label>
          <div class="col-sm-6">
            <select class="form-control" name="marital_status" id="marital_status" required>
              <option value="" selected>- Select -</option>
              <option value="Married" <?php if($row['marital_status'] == 'Married') { echo "selected"; }?>>Married</option>
              <option value="Single" <?php if($row['marital_status'] == 'Single') { echo "selected"; }?>>Single</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="position" class="col-sm-3 control-label">Division</label>
          <div class="col-sm-6">
            <select class="form-control" name="project_alloted" id="project_alloted" required>
              <option value="" selected>- Select -</option>
              <?php
                          $sql = "SELECT * FROM divisions";
                          $query = $conn->query($sql);
                          while($prow4576 = $query->fetch_assoc()){
                            ?>
                              <option value='<?php echo $prow4576['division_id']; ?>' <?php if($row['division'] == $prow4576['division_id']) { echo "selected"; }?>><?php echo $prow4576['division_name']; ?></option>
                            <?php
                          }
                        ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="position" class="col-sm-3 control-label">Job Role <?php //echo $row['$row['gender']']; ?></label>
          <div class="col-sm-6">
            <select class="form-control" name="job_id" id="job_id" required style="background:#FFFFCC;">
              <option value="" selected>- Select -</option>
              <?php
                          $sql = "SELECT DISTINCT job_title, department, job_id  FROM positions WHERE department <> ''";
                          $query = $conn->query($sql);
                          while($prow34 = $query->fetch_assoc()){
                            ?>
              <option value="<?php echo $prow34['job_id']; ?>" <?php if($row['job_id'] == $prow34['job_id']) { echo "selected"; }?>><?php echo $prow34['job_title'] ?></option>
              <?php
                          }
                        ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="schedule" class="col-sm-3 control-label">Schedule <br>
          (8 hrs/day )</label>
          <div class="col-sm-6">
            <select class="form-control" id="schedule_id" name="schedule_id" required>
              <option value="" selected>- Select -</option>
              <?php
                          $sql = "SELECT * FROM schedules";
                          $query = $conn->query($sql);
                          while($srow = $query->fetch_assoc()){
                           ?>
                              <option value='<?php echo $srow['id']; ?>' <?php if($row['schedule_id'] == $srow['id']) { echo "selected"; }?>><?php echo $srow['time_in'].' - '.$srow['time_out']; ?></option>
                            <?php
                          }
                        ?>
            </select>
          </div>
        </div>
        
		<div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-flat" name="updateProfile"><i class="fa fa-save"></i> Update Employee</button>
        </div>
        </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/employee_travel_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'position_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#posid').val(response.id);
      $('#edit_divisions').val(response.divisions);
      $('#edit_projects').val(response.projects);
	  $('#edit_description').val(response.description);
      $('#del_posid').val(response.id);
      $('#del_position').html(response.projects);
    }
  });
}
</script>
</body>
</html>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'csv', 'excel'
        ]
    } );
} );
    </script>

