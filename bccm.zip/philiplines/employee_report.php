<?php
	error_reporting(0);
 include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       User Report
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Time  Wise  Attendance Summary</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="modal-body">
			<h3 align="center"> <u>User Report</u></h3>
            	<form class="form-horizontal" method="POST" action="">
            		<input type="hidden" id="attid" name="id">
					
                <div class="col-sm-6">
                     <label for="datepicker_edit" class="col-sm-3 control-label">Division Wise</label>

                    <div class="col-lg-8"> 
                      <select class="form-control" name="divisions" id="divisions" required>
              <option value="000" selected>- All Division -</option>
              <?php
                          $sql = "SELECT * FROM divisions WHERE division_name <> ''";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                           ?>
                              <option value='<?php echo $prow['division_id']; ?>' <?php  if($_POST['divisions'] == $prow['division_id']) { echo "selected"; } ?>><?php echo $prow['division_name']; ?></option>
                            <?php
                          }
                        ?>
            </select>
                    </div>
                </div>
				<div class="col-sm-5"> 
                      <div class="date">
                   <button type="submit" class="btn btn-danger btn-flat" name="ViewReport"><i class="fa fa-save"></i> View Report</button>
                      </div>
                    </div>
				</form>
				
                
                
          	</div>
			 <div class="box-body">&nbsp;</div>
			 
            <div class="box-body">
			<h3 align="center"> <u>User Summary</u></h3>
              <table align="center" id="example"  class="table table-bordered">
                <thead bgcolor="#666699" style="color:#FFFFFF">
                  <th>User ID</th>
                  
                  <th>Name - Surname</th>
				  <th>Email</th>
                  <th>password</th>
				 
                 
                </thead>
                <tbody>
                  <?php
                     $sql = "SELECT *, employee_tnqab.emp_id AS empid FROM employee_tnqab LEFT JOIN projects ON projects.employee_id=employee_tnqab.id LEFT JOIN schedules ON schedules.id=employee_tnqab.schedule_id";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
					
                     ?>
                        <tr>
                          <td><b><?php echo $row['empid']; ?></b></td>
                                                    <td><?php echo $row['full_name']; ?></td>
						   <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['password']; ?></td>
						   
                         
                        </tr>
                      <?php 
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/attendance_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'attendance_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
	//alert(response.full_name);
      $('#datepicker_edit').val(response.date);
      $('#attendance_date').html(response.full_name);
	  $('#del_attendenceDate').val(response.date);
	  
      $('#edit_time_in').val(response.time_in);
      $('#edit_time_out').val(response.time_out);
      $('#attid').val(response.attid);
      $('#employee_name').html(response.firstname+' '+response.lastname);
      $('#del_attid').val(response.id);
      $('#del_employee_name').html(response.full_name+' ('+response.emp_id+')');
    }
  });
}
</script>
</body>
</html>

 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'pdf', 'csv', 'excel'
        ]
    } );
} );
    </script>
