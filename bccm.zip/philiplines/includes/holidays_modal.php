<!-- Add -->

<div class="modal fade" id="addnew">
  <div class="modal-dialog" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Add Holidays</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="holidaysAction.php">
        <div class="form-group">
          <label for="time_in" class="col-sm-3 control-label">Holiday Name</label>
          <div class="col-sm-9">
            <div class="bootstrap-timepicker">
              <input type="text" class="form-control" id="holiday_name" name="holiday_name" required>
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="time_out" class="col-sm-3 control-label">Holiday Date</label>
          <div class="col-sm-9">
            <div class="date">
              <input type="text" class="form-control" id="datepicker_add" name="holiday_date">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="time_in" class="col-sm-3 control-label">Remarks</label>
          <div class="col-sm-9">
            <div class="bootstrap">
              <textarea class="form-control" id="holiday_remarks" name="holiday_remarks" rows="2" cols="20"></textarea>
            </div>
          </div>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-primary btn-flat" name="add"><i class="fa fa-save"></i> Save</button>
      </form>
    </div>
  </div>
</div>
</div>
<!-- Edit -->
<div class="modal fade" id="edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Update Holidays</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="holidaysAction.php">
        <input type="hidden" id="holidayid" name="holidayid">
        <div class="form-group">
          <label for="time_in" class="col-sm-3 control-label">Holiday Name</label>
          <div class="col-sm-9">
            <div class="bootstrap-timepicker">
              <input type="text" class="form-control" id="edit_holiday_name" name="edit_holiday_name">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="time_out" class="col-sm-3 control-label">Holiday Date</label>
          <div class="col-sm-9">
            <div class="date">
              <input type="text" class="form-control" id="edit_datepicker_add" name="edit_holiday_date">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="time_in" class="col-sm-3 control-label">Remarks</label>
          <div class="col-sm-9">
            <div class="bootstrap">
              <textarea class="form-control" id="edit_holiday_remarks" name="edit_holiday_remarks" rows="2" cols="20"></textarea>
            </div>
          </div>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-success btn-flat" name="edit"><i class="fa fa-check-square-o"></i> Update</button>
      </form>
    </div>
  </div>
</div>
</div>
<!-- Delete -->
<div class="modal fade" id="delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Deleting...</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="holidaysAction.php">
        <input type="hidden" id="del_holidayid" name="del_holidayid">
        <div class="text-center">
          <p> <div class="icon"> <i class="ion ion-alert-circled"></i> </div>Are you sure you want to delete this Holiday</p>
          <h2 id="del_schedule" class="bold"></h2>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-danger btn-flat" name="delete"><i class="fa fa-trash"></i> Delete</button>
      </form>
    </div>
  </div>
</div>
</div>
