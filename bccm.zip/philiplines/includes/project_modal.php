<!-- Add -->

<div class="modal fade" id="addnew">
  <div class="modal-dialog" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Add Project</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="projectAction.php">
        <div class="form-group">
          <label for="title" class="col-sm-4 control-label">Project ID</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="projectID" name="projectID" value="<?php echo 'TNP'.rand(0000,9999); ?>">
          </div>
        </div>
		<div class="form-group">
          <label for="title" class="col-sm-4 control-label">Project Name</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="project_name" name="project_name" required>
          </div>
        </div>
		<div class="form-group">
          <label for="title" class="col-sm-4 control-label">Select Employee</label>
          <div class="col-sm-8">
<select class="form-control" name="officer_alloted[]" id="officer_alloted" required multiple="multiple">
              <?php
                          $sql = "SELECT * FROM employee_tnqab";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['id']."'>".$prow['full_name']."</option>
                            ";
                          }
                        ?>
            </select>          </div>
        </div>
		<div class="form-group">
          <label for="title" class="col-sm-4 control-label">Duration Of Project</label>
          <div class="col-sm-8">
            <select class="form-control" name="duration">
			<option value="3"> 3 Hours </option>
			<option value="4"> 4 Hours </option>
			<option value="5"> 5 Hours </option>
			<option value="6"> 6 Hours </option>
			<option value="7"> 7 Hours </option>
			<option value="8"> 8 Hours </option>
			</select>
          </div>
        </div>
		<div class="form-group">
          <label for="title" class="col-sm-4 control-label">Comments</label>
          <div class="col-sm-8">
                        <textarea class="form-control" id="comments" name="comments" rows="2" cols="20"></textarea>

          </div>
        </div>
        
        
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-primary btn-flat" name="add"><i class="fa fa-save"></i> Save</button>
      </form>
    </div>
  </div>
</div>
</div>
<!-- Edit -->
<div class="modal fade" id="edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Update Project</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="projectAction.php">
        <input type="hidden" id="posid" name="id">
        <div class="form-group">
          <label for="title" class="col-sm-3 control-label">Division Name</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="edit_division_name" name="edit_division_name" required>
          </div>
        </div>
        
        
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-success btn-flat" name="edit"><i class="fa fa-check-square-o"></i> Update</button>
      </form>
    </div>
  </div>
</div>
</div>
<!-- Delete -->
<div class="modal fade" id="delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><b>Deleting...</b></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal" method="POST" action="projectAction.php">
        <input type="hidden" id="del_posid" name="id">
        <div class="text-center">
          <p>Delete Project</p>
          <h2 id="del_position" class="bold"></h2>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
        <button type="submit" class="btn btn-danger btn-flat" name="delete"><i class="fa fa-trash"></i> Delete</button>
      </form>
    </div>
  </div>
</div>
</div>
