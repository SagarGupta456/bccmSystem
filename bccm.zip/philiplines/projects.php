<?php
error_reporting(0);
 include 'includes/session.php'; ?>
<?php include 'includes/header.php';
//print_r($_SESSION);
//exit;
 ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee Tickets
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Employee Projects</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <a href="#addnew" data-toggle="modal" class="btn btn-primary btn-sm btn-flat" style="margin-left:45%;"><i class="fa fa-plus"></i> New Ticket</a>
            </div>
            <div class="box-body">
              <table align="center" id="example" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:14px;" class="table table-bordered">
                <thead bgcolor="#666699" style="color:#FFFFFF">
				<th>#</th>
                  <th>Project ID</th>
				  <th>Project Name</th>
				  <th>Employee</th>
				  <th>Duration</th>
				  <th>Comments</th> 
                  <th>Action</th>
                </thead>
                <tbody>
                  <?php
                    $sql = "SELECT *  FROM projects WHERE project_name <> ''";
                    $query = $conn->query($sql);
					$count = 0;
                    while($row = $query->fetch_assoc()){
					$empID = $row['employee_id'];
					$sql4363 = "SELECT * FROM employee_tnqab WHERE id = '$empID'";
						$query4363 = $conn->query($sql4363);
					$row3546 = $query4363->fetch_assoc();
					$count++;
                    ?>
                        <tr>
						 <td><?php echo $count; ?></td>
                          <td><?php echo $row['projectID']; ?></td>
						  <td><?php echo $row['project_name']; ?></td>
						  <td><?php echo $row3546['full_name']; ?>(<?php echo $row3546['emp_id']; ?>)</td>
						  <td><?php echo $row['duration']; ?> Hours</td>
						  <td><?php echo $row['comments']; ?></td>
						  
                          <td>
                            <button class='btn btn-danger btn-sm delete btn-flat' data-id='<?php echo $row['id'] ?>'><i class='fa fa-trash'></i> Delete</button>
                          </td>
                        </tr>
                      <?php 
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/project_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $('.edit').click(function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $('.delete').click(function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'project_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
	
	//alert("yess"+response);
      $('#posid').val(response.division_id);
      $('#edit_division_name').val(response.division_name);
      $('#edit_projects').val(response.projects);
	  $('#edit_description').val(response.description);
      $('#del_posid').val(response.id);
      $('#del_position').html(response.projects);
    }
  });
}
</script>
</body>
</html>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
     <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
              <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
                   <script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js "></script>
     





    <script>
      $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
           'csv', 'excel'
        ]
    } );
} );
    </script>
